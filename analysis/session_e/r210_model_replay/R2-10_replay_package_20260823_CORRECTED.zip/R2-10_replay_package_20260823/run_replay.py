#!/usr/bin/env python3
"""
R2-10 second-model replay runner  --  ROBOT-D-26-01090 (Robotics and Autonomous Systems)

Replays the 69 archived L3b VLM decisions of Session E through one or more
alternative models, under conditions identical to the original run.

ONLY the model identifier varies. Prompt, image, parser contract, inference
options, endpoint and acceptance criteria are byte-for-byte the originals.

Usage
-----
    python3 run_replay.py --models qwen3.5:4b llava:7b gemma3:4b
    python3 run_replay.py --models llava:7b --limit 3          # smoke test first

Outputs (written to ./results/)
-------------------------------
    environment.json                  host / GPU / Ollama identity
    results_<model_slug>.csv          one row per record, parsed fields
    raw_<model_slug>.jsonl            full Ollama responses, unmodified
    RUN_LOG.txt

Nothing in this script needs the robots, the context server or ROS.
"""
import argparse, base64, csv, hashlib, json, os, platform, re, shutil
import subprocess, sys, time, urllib.request, urllib.error

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")

# The Session E control model. Its digest is recorded in sessions.csv on all 214
# audit sessions. If this model is in --models, the runner refuses to start unless
# the installed digest matches, because the whole point of the control arm is that
# it is the SAME model, not merely the same tag.
CONTROL_MODEL = "qwen3.5:4b"
CONTROL_DIGEST = ("0c8faadc50c205b83c634430c1dae6d1a4896c9b818cb8f290aa34d535265018")

# ---- frozen from vlm_navigator_node_v4_8_review.py :: call_vlm() ------------
# Do not change these. They are the original inference conditions.
OPTIONS = {"num_predict": 500, "temperature": 0.3, "num_ctx": 16384}
THINK   = False
ENDPOINT = "/api/chat"
TIMEOUT  = 300
# ----------------------------------------------------------------------------

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(HERE, "results")


def md5_bytes(b):
    return hashlib.md5(b).hexdigest()


def slug(model):
    return re.sub(r"[^A-Za-z0-9._-]", "_", model)


def http_json(url, payload=None, timeout=30):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(
        url, data=data,
        headers={"Content-Type": "application/json"} if data else {})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())


# ---- parser contract ------------------------------------------------------
# Mirrors call_vlm() in vlm_navigator_node_v4_8_review.py up to the point where the
# original returns parsed.get('node_id') UNCHANGED. This runner deliberately does
# NOT coerce a string node_id into an integer: the original did not, so accepting
# {"node_id": "9"} here would inflate a second model's apparent contract compliance.
# The raw value and its type are recorded instead, and the layered outcome is
# resolved offline against the graph and the negation constraint.
def parse_response(result):
    """Returns a dict describing the outcome in separable layers."""
    msg = result.get("message") or {}
    raw_content = (msg.get("content") or "").strip()
    if not raw_content:
        raw_content = (msg.get("thinking") or "").strip()

    content = raw_content
    if "<think>" in content:
        i = content.rfind("</think>")
        if i != -1:
            content = content[i + 8:].strip()
    content = content.replace("```json", "").replace("```", "").strip()

    out = {"raw_content": raw_content, "json_parse": "none",
           "node_id_raw": "", "node_id_type": "missing",
           "node_id_int": "", "contract_ok": False, "reason": ""}

    parsed = None
    try:
        parsed = json.loads(content)
        out["json_parse"] = "direct"
    except json.JSONDecodeError:
        m = re.search(r"\{.*?\}", content, re.DOTALL)
        if m:
            try:
                parsed = json.loads(m.group(0))
                out["json_parse"] = "extracted"
            except json.JSONDecodeError:
                out["json_parse"] = "malformed"
        else:
            out["json_parse"] = "no_json"

    if not isinstance(parsed, dict):
        if parsed is not None:
            out["json_parse"] = "not_an_object"
        return out

    out["reason"] = str(parsed.get("reason", ""))[:500]
    if "node_id" not in parsed:
        return out
    nid = parsed["node_id"]
    out["node_id_raw"] = json.dumps(nid, ensure_ascii=False)
    out["node_id_type"] = type(nid).__name__
    # contract = the original contract: node_id is a JSON integer, not a string.
    if isinstance(nid, int) and not isinstance(nid, bool):
        out["node_id_int"] = nid
        out["contract_ok"] = True
    return out


def call_model(model, prompt, image_b64):
    messages = [{"role": "user", "content": prompt,
                 "images": [image_b64] if image_b64 else []}]
    payload = {"model": model, "stream": False, "messages": messages,
               "think": THINK, "options": OPTIONS}
    body = json.dumps(payload).encode()
    req = urllib.request.Request(
        OLLAMA_URL + ENDPOINT, data=body,
        headers={"Content-Type": "application/json"})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        result = json.loads(resp.read())
    t1 = time.time()
    td = result.get("total_duration", 0)
    result["_wall_ms"] = round((t1 - t0) * 1000.0, 2)
    result["_total_ms"] = round(td / 1e6, 2) if td else 0.0
    result["_queue_ms"] = round(max(0.0, result["_wall_ms"] - result["_total_ms"]), 2)
    result["_request_sent_at"] = t0
    result["_response_at"] = t1
    return result


def model_identity(model):
    info = {"model": model, "digest": None, "quantization": None,
            "parameter_size": None, "family": None}
    try:
        show = http_json(OLLAMA_URL + "/api/show", {"model": model})
        d = show.get("details") or {}
        info["quantization"] = d.get("quantization_level")
        info["parameter_size"] = d.get("parameter_size")
        info["family"] = d.get("family")
        info["digest"] = show.get("digest")
    except Exception as ex:
        info["show_error"] = repr(ex)
    if not info["digest"]:
        try:
            for m in (http_json(OLLAMA_URL + "/api/tags").get("models") or []):
                if model in (m.get("name"), m.get("model")):
                    info["digest"] = m.get("digest")
                    info["size_bytes"] = m.get("size")
                    break
        except Exception as ex:
            info["tags_error"] = repr(ex)
    return info


def environment(models):
    env = {
        "captured_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "host": platform.node(),
        "os": platform.platform(),
        "python": sys.version.split()[0],
        "ollama_url": OLLAMA_URL,
        "inference_options": OPTIONS,
        "think": THINK,
        "endpoint": ENDPOINT,
    }
    try:
        env["ollama_version"] = http_json(OLLAMA_URL + "/api/version").get("version")
    except Exception as ex:
        env["ollama_version_error"] = repr(ex)
    if shutil.which("nvidia-smi"):
        try:
            q = ("name,driver_version,memory.total,compute_cap")
            out = subprocess.run(
                ["nvidia-smi", f"--query-gpu={q}", "--format=csv,noheader"],
                capture_output=True, text=True, timeout=20).stdout.strip()
            env["gpu"] = out
            env["gpu_driver_version"] = out.split(",")[1].strip() if "," in out else None
        except Exception as ex:
            env["gpu_error"] = repr(ex)
    else:
        env["gpu"] = "nvidia-smi not found"
    env["models"] = {m: model_identity(m) for m in models}
    return env


# Latency naming, deliberately explicit. Session E's timing.vlm_ms is the CLIENT-SIDE
# wall time around the call, so client_wall_ms is the quantity comparable to it.
# ollama_total_ms is Ollama's own total_duration and is NOT the same measurement.
FIELDS = ["record_key", "experiment_id", "model", "model_digest", "quantization",
          "parameter_size", "prompt_md5", "image_md5",
          "json_parse", "node_id_raw", "node_id_type", "node_id_int", "contract_ok",
          "reason", "negation_forbidden_nodes",
          "client_wall_ms", "ollama_total_ms", "queue_ms", "load_ms",
          "prompt_eval_count", "prompt_eval_duration_ms",
          "eval_count", "eval_duration_ms", "tokens_per_sec",
          "done_reason", "error", "attempt", "timestamp_utc"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", required=True,
                    help="Ollama model identifiers. Include qwen3.5:4b as the "
                         "same-model control arm.")
    ap.add_argument("--limit", type=int, default=0,
                    help="Replay only the first N records (smoke test).")
    ap.add_argument("--set", choices=["main", "no_image"], default="main",
                    help="main = the 69 image-backed records (default). "
                         "no_image = the 14 escalated prompts whose start frame "
                         "was never archived; replayed text-only, NOT comparable "
                         "to the original conditions. See PROTOCOL.md section 9.")
    ap.add_argument("--retries", type=int, default=2,
                    help="Retries on transport error only, never on a bad parse.")
    args = ap.parse_args()

    os.makedirs(RESULTS, exist_ok=True)
    mfile = ("manifest_inputs.csv" if args.set == "main"
             else "manifest_escalated_no_image.csv")
    manifest = list(csv.DictReader(open(os.path.join(HERE, mfile), encoding="utf-8")))
    if args.limit:
        manifest = manifest[:args.limit]

    env = environment(args.models)

    # Hard gate: the control arm is only a control if it is the same model.
    if CONTROL_MODEL in args.models:
        got = (env["models"].get(CONTROL_MODEL) or {}).get("digest") or ""
        got = got.replace("sha256:", "")
        if not got:
            print(f"\n!! Could not read the digest of {CONTROL_MODEL}. Check it by hand\n"
                  f"   against {CONTROL_DIGEST[:12]}... before running.\n")
            sys.exit(3)
        if got != CONTROL_DIGEST:
            print(f"\n!! ABORT — {CONTROL_MODEL} is NOT the Session E model.\n"
                  f"   installed: {got}\n   expected : {CONTROL_DIGEST}\n"
                  f"   Do not pull or re-tag it. Recover the original model first.\n")
            sys.exit(3)
        print(f"control model digest verified: {CONTROL_MODEL} = {got[:16]}...")

    with open(os.path.join(RESULTS, "environment.json"), "w", encoding="utf-8") as f:
        json.dump(env, f, indent=2, ensure_ascii=False)
    print(json.dumps(env, indent=2, ensure_ascii=False)[:1500])

    log = open(os.path.join(RESULTS, "RUN_LOG.txt"), "a", encoding="utf-8")

    def say(s):
        print(s); log.write(s + "\n"); log.flush()

    say(f"\n===== run started {env['captured_at_utc']}  set={args.set}  "
        f"records={len(manifest)} =====")

    for model in args.models:
        ident = env["models"].get(model, {})
        s = slug(model)
        suffix = "" if args.set == "main" else "_noimage"
        fcsv = open(os.path.join(RESULTS, f"results_{s}{suffix}.csv"), "w",
                    encoding="utf-8", newline="")
        w = csv.DictWriter(fcsv, fieldnames=FIELDS); w.writeheader()
        fraw = open(os.path.join(RESULTS, f"raw_{s}{suffix}.jsonl"), "w",
                    encoding="utf-8")
        t_model = time.time()

        for i, row in enumerate(manifest, 1):
            prompt = open(os.path.join(HERE, row["prompt_file"]),
                          encoding="utf-8").read()
            pmd5 = md5_bytes(prompt.encode("utf-8"))
            if pmd5 != row["prompt_md5"]:
                say(f"  !! prompt md5 mismatch on {row['record_key']} — ABORT")
                sys.exit(2)
            if args.set == "main":
                raw_img = open(os.path.join(HERE, row["image_file"]), "rb").read()
                imd5 = md5_bytes(raw_img)
                if imd5 != row["image_md5"]:
                    say(f"  !! image md5 mismatch on {row['record_key']} — ABORT")
                    sys.exit(2)
                image_b64 = base64.b64encode(raw_img).decode()
            else:
                imd5, image_b64 = "", None

            rec = {k: "" for k in FIELDS}
            rec.update(record_key=row["record_key"],
                       experiment_id=row.get("experiment_id", ""),
                       model=model, model_digest=ident.get("digest"),
                       quantization=ident.get("quantization"),
                       parameter_size=ident.get("parameter_size"),
                       prompt_md5=pmd5, image_md5=imd5,
                       negation_forbidden_nodes=row.get("negation_forbidden_nodes", ""),
                       timestamp_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
            result = None
            for attempt in range(1, args.retries + 2):
                rec["attempt"] = attempt
                try:
                    result = call_model(model, prompt, image_b64)
                    break
                except Exception as ex:
                    rec["error"] = repr(ex)[:300]
                    say(f"  [{model}] {row['record_key']} transport error "
                        f"attempt {attempt}: {rec['error']}")
                    time.sleep(3)
            if result is None:
                rec["json_parse"] = "transport_failed"
                w.writerow(rec); fcsv.flush(); continue

            po = parse_response(result)
            ec = result.get("eval_count") or 0
            ed = result.get("eval_duration") or 0
            rec.update(
                json_parse=po["json_parse"], node_id_raw=po["node_id_raw"],
                node_id_type=po["node_id_type"], node_id_int=po["node_id_int"],
                contract_ok=po["contract_ok"], reason=po["reason"],
                client_wall_ms=result["_wall_ms"],
                ollama_total_ms=result["_total_ms"],
                queue_ms=result["_queue_ms"],
                load_ms=round((result.get("load_duration") or 0) / 1e6, 2),
                prompt_eval_count=result.get("prompt_eval_count"),
                prompt_eval_duration_ms=round(
                    (result.get("prompt_eval_duration") or 0) / 1e6, 2),
                eval_count=ec,
                eval_duration_ms=round(ed / 1e6, 2),
                tokens_per_sec=round(ec / (ed / 1e9), 1) if ed else 0.0,
                done_reason=result.get("done_reason"), error="")
            w.writerow(rec); fcsv.flush()
            fraw.write(json.dumps(
                {"record_key": row["record_key"], "model": model,
                 "raw_content": po["raw_content"], "response": result},
                ensure_ascii=False) + "\n")
            fraw.flush()
            say(f"  [{model}] {i:3d}/{len(manifest)} {row['record_key']} "
                f"-> node_id={po['node_id_raw'] or '-'} ({po['json_parse']}, "
                f"contract={'ok' if po['contract_ok'] else 'FAIL'}) "
                f"{result['_wall_ms']:.0f} ms wall")

        fcsv.close(); fraw.close()
        say(f"  [{model}] done in {time.time()-t_model:.0f} s")

    say("===== run complete =====")
    log.close()


if __name__ == "__main__":
    main()
