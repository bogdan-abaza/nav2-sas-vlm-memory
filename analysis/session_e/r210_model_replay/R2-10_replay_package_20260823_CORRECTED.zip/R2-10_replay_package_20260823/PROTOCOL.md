# R2-10 — Second-model replay protocol

**Manuscript:** *A Semantic Autonomy Framework for VLM-Integrated Indoor Mobile Robots*
**Journal:** Robotics and Autonomous Systems — **ROBOT-D-26-01090** (major revision)
**Revision deadline:** 4 September 2026 · **Dispatched:** 23 August 2026
**Package:** `R2-10_replay_package_20260823`

---

## 1. What Reviewer 2 asked, and what this answers

Reviewer 2, point 10: the manuscript claims model-agnostic L3b operation but reports
one model only (`qwen3.5:4b`). The claim of agnosticism concerns the **interface
contract** ⟨A, O, V, L⟩, not performance equivalence — but without a second model
that distinction is asserted, not demonstrated.

This replay demonstrates it. It re-executes the **69 archived L3b VLM decisions of
Session E** through one or more alternative models, holding every other condition
fixed. It needs **no robots, no ROS, no context server** — only a workstation with
Ollama and a GPU.

The result feeds manuscript §6.7 (protocol) and §7.7 (results).

---

## 2. The one thing that must not be got wrong

> **Use `image_start`. Never `image_finish`.**

`image_start` is the frame captured **before** navigation begins. It is the actual
visual input to the L3b semantic decision — the robot looks, then decides where to go.
`image_finish` is the post-arrival confirmation frame, captured **after** the decision
had already been made and executed. It was never an input to L3b.

Two consequences:

- Replaying `image_finish` would answer a question nobody asked, and would leak the
  outcome into the input.
- `image_start_md5` is populated on **69/69** `L3b_vlm` records; `image_finish_md5`
  on only **58/69**. The correct field is also the complete one.

**This package has already resolved this.** `images/` contains only start frames,
each verified byte-for-byte against the MD5 recorded in the audit log at capture
time. Nothing needs to be selected by hand.

---

## 3. Frozen conditions — only the model identifier varies

Everything below is reproduced exactly from the original run. `run_replay.py`
enforces it; do not edit these values.

| Condition | Value | Where it comes from |
|---|---|---|
| Endpoint | `POST {OLLAMA_URL}/api/chat` | `vlm_navigator_node_v4_8_review.py :: call_vlm()` |
| Payload | `{model, stream:false, messages, think:false, options}` | same |
| Inference options | `num_predict: 500`, `temperature: 0.3`, `num_ctx: 16384` | same |
| Prompt | `extra.vlm_prompt_full`, **verbatim**, including the memory prefix | audit JSONL |
| Image | `images.start`, base64, single image in `messages[0].images` | audit JSONL |
| Parser contract | `{"node_id": <int>, "reason": "<brief reason>"}` | same |
| Parser behaviour | strip `<think>…</think>`, strip ``` fences, else first `{...}` by regex | copied into `run_replay.py :: parse_response()` |
| **Post-VLM acceptance** — graph-node validity, negation validation, `-1` abstention handling | lives in the navigator, **not** in the runner | **resolved offline** from the recorded raw outputs; see §8 |
| Graph / ontology / memory state | already baked into each prompt — nothing to configure | — |

**The memory prefix is part of the prompt and is not to be stripped.** 65 of the 69
prompts include it (`memory_prefix_included = True`); the remaining **4 are the E6
memory-off ablation** and legitimately carry no prefix and no `digest_content_md5`.
That asymmetry is the experiment, not a defect — keep it.

### Original run identity, for the record

```
navigator version   v4.8-review
git commit          f973aa0c4920e47cdd85d7e4e263e3b66fb41ddc   (git_dirty = False)
model               qwen3.5:4b
model digest        0c8faadc50c205b83c634430c1dae6d1a4896c9b818cb8f290aa34d535265018
quantization        Q4_K_M
Ollama              0.30.2
GPU driver          580.173.02
sas_text            1.2.0
route graph md5     e0130b78b00ec55822dbc39a41429817
ontology md5        2e48375071c0e4ea7cd38c0e48ef97c5
J threshold 0.75 · abstention margin 0.10
```

---

## 4. The control arm — please do not skip it

The original inference ran at **`temperature = 0.3`, not 0**. The decoding is
therefore stochastic. Without a control, any disagreement between models is
confounded with ordinary sampling noise, and a reviewer will say so.

**So the first arm is `qwen3.5:4b` itself** — the same model, the same prompts, the
same images, re-run on the same machine. It gives a **same-model replay reference**:
the observed self-agreement of the original model with its own archived answers under
stochastic decoding.

That reference is reported **alongside** the alternative arms, never subtracted from
them. A single re-run of 69 cases does not estimate a noise floor precisely enough to
be used as an arithmetic correction; it establishes the order of magnitude of
self-disagreement, which is what makes a between-model difference interpretable.

If the machine has spare time, a second Qwen pass tightens that reference. It is not
required for R2-10.

```
Arm 0 (control)   qwen3.5:4b        same model, new host
Arm 1..n          alternative VLMs  e.g. llava:7b, gemma3:4b, minicpm-v, qwen2.5vl:7b
```

Two alternative arms is enough for the claim. Three is better if the machine is free.

---

## 5. How to run it

> **Never `ollama pull qwen3.5:4b` on this machine.** The tag may re-resolve to a newer
> manifest and the Session E control model would be gone. Verify it, do not fetch it.

```bash
# 0. confirm the control model is the Session E one, BEFORE anything else
ollama list | grep qwen3.5:4b        # ID must start 0c8faadc50c2

# 1. pull ONLY the alternative arms
ollama pull gemma3:4b
ollama pull llava:7b                 # optional third arm

# 2. smoke test — 3 records. The runner aborts if the control digest is wrong.
python3 run_replay.py --models qwen3.5:4b --limit 3

# 3. full run, sequentially
python3 run_replay.py --models qwen3.5:4b gemma3:4b
python3 run_replay.py --models llava:7b            # optional, afterwards
```

The runner refuses to start if `qwen3.5:4b` is requested and its installed digest is
not `0c8faadc50c205b8…`. That gate is the reason the control arm means anything.

**Run the arms one model at a time, with nothing else on the GPU.** Concurrency is
measured separately in block E5; contention here would corrupt the latency comparison.

Rough cost: 69 records × ~10 s ≈ **12 minutes per arm**. Larger models are slower.

Every prompt and image is MD5-checked as it is read; the run aborts on the first
mismatch, so a corrupted copy cannot quietly produce a wrong result.

---

## 6. What comes back

Everything in `results/`:

| File | Contents |
|---|---|
| `environment.json` | host, OS, GPU, driver, Ollama version, and per-model identity — name, **digest**, quantization level, parameter size |
| `results_<model>.csv` | one row per record. Outcome in separable layers: `json_parse` (direct / extracted / malformed / no_json / not_an_object), `node_id_raw` (verbatim JSON value), `node_id_type`, `node_id_int`, `contract_ok`. Latency named for what it is: **`client_wall_ms`** (comparable to Session E `timing.vlm_ms`), `ollama_total_ms` (Ollama `total_duration`, a different measurement), `queue_ms`, `load_ms`. Plus eval counts, `done_reason`, prompt MD5, image MD5, `negation_forbidden_nodes` |
| `raw_<model>.jsonl` | the complete unmodified Ollama response for every call |
| `RUN_LOG.txt` | progress log |

Please return the whole `results/` directory, unedited. The raw JSONL matters: if a
model wraps its JSON in prose, we want to show the parser recovering it rather than
assert that it did.

**Nothing needs to be interpreted at your end.** Do not filter failures, do not retry
a call because the answer looks wrong, do not adjust a prompt that a model dislikes.
A refusal, a malformed answer or a wrong node **is data** — it is precisely what
"model-agnostic" has to survive. The script retries only on transport errors.

---

## 7. The sealed reference key

`sealed/reference_key.csv` holds the original `qwen3.5:4b` outputs — chosen node,
reason, latency, expected node.

```
sealed/reference_key.csv     md5  0f68b90f5a09464e94d6f429e8de3300
manifest_inputs.csv          md5  64b19056ec738b14d89be37153fd619a
```

It ships with the package so the analysis is reproducible end to end, but it is
**not read by the runner and must not be consulted while running**. It is opened
after the arms are complete, exactly as the E7 sealed instruction set was.
The MD5 above is what lets us state in the response letter that it was not touched.

---

## 8. What we compute afterwards (our side, for context)

**Two denominators, always both named.** The replay executes **69** archival
accepted-node cases. One of them belongs to the E0 start gate, which is excluded from
every primary rate in the paper. So primary rates are over **68**, and the 69 is
reported as the archival execution count. `results_<model>.csv` carries
`experiment_id`, so the split is a one-line filter.

**Outcome is resolved in layers, not as a single "parse ok".** The runner records the
raw model output and stops at the point where the original navigator's `call_vlm()`
stops. Everything downstream of that is recomputed offline, so that each layer can be
compared separately:

| Layer | Source | What it answers |
|---|---|---|
| 1. JSON obtained | `json_parse` | did the reply yield a JSON object at all, directly or by extraction |
| 2. Integer contract | `node_id_type`, `contract_ok` | is `node_id` a JSON **integer**, as the contract requires — `"9"` as a string is a contract failure, not a success |
| 3. Graph-valid target | offline, against `route_graph_fiir.geojson` | does the node exist |
| 4. Negation-safe | offline, against `negation_forbidden_nodes` in the manifest | on the 13 negation cases, did the model avoid the forbidden nodes |
| 5. Accepted target | offline, original post-VLM rule | what the navigator would have done with this answer |

The runner deliberately does **not** coerce a string `node_id` into an integer. The
original did not either; accepting `{"node_id": "9"}` would silently inflate a second
model's apparent contract compliance.

Then:

1. **Contract compliance per model** at layers 1 and 2, over 68 primary cases (69
   archival). `Qwen 69/69` at layer 1 is true by construction — the cohort is defined by
   it — and is never quoted as a comparative figure.
2. **Agreement with the original accepted node**, overall and split by escalation
   reason. **Over the 69 replay cases** the split is `no_deterministic_match` 54,
   `negation_detected` 13, `location_conflict` 2. Those three numbers belong to the 69
   and to nothing else — over the 91 timed records the split is 54 / 35 / 2, and over
   all 105 call-path records it is 64 / 39 / 2.
3. **Negation compliance — and the limit of what this replay can say about it.**
   Session E has **39 negation activations** on the VLM call path: **22** where the
   model returned `node_id = -1` and clarification was requested, **13** where it
   returned a non-forbidden node, and **4** that did not parse. Only the **13** are in
   the replay cohort; the 22 successful abstentions and the 4 parse failures have no
   persisted image.

   So the replay tests whether a second model selects a forbidden destination **on 13 of
   the 39 negation cases**, and specifically on the 13 where the original answered with
   a node rather than abstaining. It cannot tell us whether a second model would have
   abstained on the other 22. This is the R1-8 safety question and it remains the most
   consequential comparison in the replay — but its coverage is 13/39, and the paper
   must say so.
4. **Latency** per model from **`client_wall_ms`**, which is the quantity comparable to
   Session E's `timing.vlm_ms` (verified: the archived `timing.vlm_ms` tracks the
   client-side wall time to within a median of 0.7 ms, while Ollama's `total_duration`
   differs by 1.6 ms). `ollama_total_ms` is recorded too but is a different measurement
   and is never compared against the archived figure. Original reference: mean
   10,450 ms, median 11,164 ms over the 69.
5. **Offline M3 promotion behaviour** — recomputed instruction-level consistency under
   the unchanged rule (frequency ≥ 3 ∧ consistency ≥ 0.80), applying the extractor's own
   convention `consistency = round(dominant / total, 2)` **before** the threshold
   comparison. The question a reviewer actually cares about is whether a different model
   would have promoted a *different* association into shared memory.
6. **Same-model replay reference** from the control arm — the original model's observed
   self-agreement with its own archived answers under stochastic decoding. Reported
   **alongside** the alternative arms, never subtracted from them. One 69-case pass does
   not estimate a noise floor precisely enough to be used as an arithmetic correction;
   it establishes the order of magnitude of self-disagreement, which is what makes a
   between-model difference interpretable.

Claim to be adopted in the manuscript, in place of the current unqualified one:

> *interface-level model agnosticism, validated across N models with respect to
> contract compliance* — reported separately from semantic performance, which varies
> by model.

---

## 9. What is replayed — the Session E VLM population dictionary

Session E has **105 records that entered the VLM call path**. They are not
interchangeable, and every number below names which set it belongs to.

| Class | n | Prompt | `vlm_ms` recorded | Start image | Replayed |
|---|---:|---|---|---|---|
| `L3b_vlm` — model answered, reply parsed, node accepted | **69** | 69/69 | yes | **69/69**, MD5-verified | **yes — the replay cohort** |
| `L3b_vlm_negation_blocked` — model answered `node_id = -1`, clarification requested | **22** | 22/22 | yes (mean 8,878 ms) | **0/22** | no |
| `escalated` — model answered, reply did **not** parse | **14** | 14/14 | no (`vlm_error` instead) | **0/14** | optional, text-only |
| **Total call-path attempts** | **105** | | **91 timed** (69 + 22) | **69 with image** | |

Two consequences follow, and both go into the paper rather than being managed away.

**The 22 are not failures.** The negation guard put the prohibition into the prompt and
the model complied, returning `-1`. They are successful safety outcomes, and they cost
7–12 s of inference each. They are excluded from the replay only because no image was
persisted for them — not because anything went wrong.

**The replay cohort is outcome-conditioned.** The 69 are exactly the cases where the
original system reached an *accepted navigational resolution* **and** persisted the
image. A second model's parse rate, target agreement and latency measured on them are
conditional on that outcome class. They are **not** unconditional model-agnostic
performance over all 105 attempts, and `Qwen 69/69` is true by construction and must
never be quoted as a comparative success rate.

Escalation reasons depend on the denominator and must always be labelled:

```
69 accepted   : 54 no-match / 13 negation /  2 conflict
91 timed      : 54 no-match / 35 negation /  2 conflict
105 call-path : 64 no-match / 39 negation /  2 conflict
```

### Composition of the replay cohort (69)

| Block | n | | Platform | n |
|---|---:|---|---|---:|
| E7 sealed set | 21 | | xplorer-b | 45 |
| E4 promotion | 16 | | xplorer-c | 24 |
| E2 negation | 15 | | | |
| E5 concurrency | 6 | | | |
| E4b induction | 6 | | | |
| E6 memory-off | 4 | | | |
| E0 start gate | 1 | | | |
| **Total** | **69** | | | **69** |

41 distinct `semantic_intent_id` values. All 69 prompts and all 69 images are distinct.
E0 contributes one record; it is replayed but dropped at analysis time, consistently
with the E0 exclusion rule used everywhere else.

### The optional text-only arm (the 14)

The 14 unparsed attempts keep their prompts. They can be replayed without an image:

```bash
python3 run_replay.py --models qwen3.5:4b llava:7b --set no_image
```

Not a like-for-like comparison — the originals carried an image — so results land in
`results_<model>_noimage.csv` and stay separate. Run it last, or not at all.

**Worth knowing before interpreting it:** 4 of the 14 original failures are
`done_reason = length, eval_count = 500` — the model hit the `num_predict: 500` cap and
was truncated mid-answer. The other 10 are malformed JSON. Since the replay keeps
`num_predict: 500` to preserve the original conditions, a more verbose model will hit
the same ceiling more often. If that happens it must be reported as an interaction with
a shared output cap, not as the model being worse at the contract.

---

## 10. Declared limitations

- **Outcome-conditioned cohort** — see §9. The 69 are the accepted-node, image-complete
  cases; the other 36 (22 safe abstentions + 14 parse failures) have no persisted image
  and cannot be replayed faithfully.
- The replay reuses archived images. It reproduces the semantic decision, **not** the
  field lighting conditions of 20–21 August.
- Absolute latencies are host-dependent. The control arm makes the *relative*
  comparison valid, which is the one being claimed.
- `temperature = 0.3` means single-sample outputs. The control arm bounds this; we do
  not claim determinism.

---

## 11. If it cannot be completed in time

Then it is not run in a hurry. The manuscript states model-agnostic validation as
declared future work **with this protocol printed in full**, which is a defensible
position. A rushed or partial replay is worse than a clearly deferred one.

Please tell us as early as you can either way — the integration window is 1–3 September, and the
response letter is finalised on 4 September, the submission deadline.
