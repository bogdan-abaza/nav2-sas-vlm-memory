# R2-10 replay package — read this first

**ROBOT-D-26-01090** (Robotics and Autonomous Systems, major revision)
Built 23 August 2026 from the frozen Session E archive.

Andrei — this is self-contained. No robots, no ROS, no context server, no access to
our repository. A workstation with a GPU and Ollama is the whole requirement.

## In one minute

```bash
ollama list | grep qwen3.5:4b     # ID MUST start 0c8faadc50c2 — verify, never pull
ollama pull gemma3:4b             # pull ONLY the alternative arms
python3 run_replay.py --models qwen3.5:4b --limit 3        # smoke test
python3 run_replay.py --models qwen3.5:4b gemma3:4b
```

> **Never run `ollama pull qwen3.5:4b` on this machine.** The tag can re-resolve to a
> newer manifest and the Session E control model is then gone. The runner aborts if the
> installed digest is not the Session E one.

Then send back the whole `results/` directory. That is the deliverable.

**Time:** roughly 12 minutes per model for all 69 records. Three arms, under two hours.

## Three things that matter

1. **`qwen3.5:4b` is the first arm and it is not optional.** The original ran at
   `temperature = 0.3`, so decoding is stochastic. Re-running the original model gives
   the model's **self-agreement with its own archived answers** — the reference that
   makes a between-model difference interpretable. It is reported alongside the other
   arms, not subtracted from them.
2. **Run the arms one at a time, with nothing else on the GPU.** Concurrency is a
   separate experiment (block E5); contention here would corrupt the latency figures.
3. **Do not clean the output.** A refusal, a malformed JSON reply or a wrong node is
   the result, not a failed run. Never retry a call because the answer looks wrong,
   and never adjust a prompt a model dislikes. The script retries transport errors
   only.

## What is in here

```
README.md                 this file
PROTOCOL.md               the full protocol, and the reasoning behind each constraint
run_replay.py             the runner — Python 3 standard library only
manifest_inputs.csv       69 records: identity, prompt file, image file, MD5s
prompts/                  69 prompts, verbatim, including the memory prefix
images/                   69 start frames, MD5-verified against the audit log
manifest_escalated_no_image.csv   the optional 14 (see below)
prompts_no_image/         14 prompts whose start frame was never archived
sealed/reference_key.csv  original qwen3.5:4b outputs — NOT read by the runner
CHECKSUMS.md5             every file in the package
```

Verify the transfer before running:

```bash
md5sum -c CHECKSUMS.md5
```

The runner also re-checks every prompt and image MD5 as it goes, and aborts on the
first mismatch, so a corrupted copy cannot quietly produce a wrong answer.

## Optional fourth arm, only if the machine is free

Session E has 105 records on the VLM call path: 69 accepted-node resolutions (the main
set), 22 safe `node_id = -1` clarification outcomes, and 14 whose reply did not parse.
Only the 69 have a persisted start frame. The 14 keep their prompts and can be replayed
text-only:

```bash
python3 run_replay.py --models qwen3.5:4b llava:7b --set no_image
```

Not a like-for-like comparison, and we say so in the paper. Run it last, or not at all.

## The one substantive detail

The images are **start frames** — captured before navigation, the actual input to the
L3b decision — not the post-arrival confirmation frames. That distinction was got
wrong in an earlier draft of this protocol and is the reason the package ships the
images already selected rather than asking you to pick them. `PROTOCOL.md` §2 explains
why it matters.

## Questions

Anything ambiguous, ask before running rather than deciding locally — a documented
question costs an email, an undocumented judgement call costs the arm. If the machine
is not free before 1 September, tell us early: we have a fallback that states the
protocol as declared future work, and it is much better used deliberately than in a
panic.
